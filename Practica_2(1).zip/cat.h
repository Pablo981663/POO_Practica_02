#ifndef CAT_H
#define CAT_H


class Gato{

    public:
    Gato (int edadInicial, int pesoInicial);
    int ObtenerEdad()const;
    void AsignarEdad (int edad);
    int ObtenerPeso() const;
    void AsignarPeso (int peso);
    ~Gato();
    void Maullar ();

    private:
        int suEdad,suPeso;
};

#endif
