#include <iostream>
#include "cat.h"

using namespace std;

Gato::Gato (int edadInicial, int pesoInicial){
    suEdad=edadInicial;
    suPeso=pesoInicial;
    cout<<"Se ha creado un Gato de edad: "<<edadInicial <<endl;
    cout<<"y tiene un peso de: "<<pesoInicial<<"kg"<<endl;
}

Gato::~Gato(){
    cout<<"El Gato se destruira en 3, 2, 1... ya fue." <<endl;
}

int Gato::ObtenerEdad()const{
    return suEdad;
}
void Gato::AsignarEdad(int edad){
    suEdad=edad;
}
int Gato::ObtenerPeso()const{
    return suPeso;
}
void Gato::AsignarPeso(int peso){
    suPeso=peso;
}
void Gato::Maullar(){
cout<<"Miawwwww"<<endl;
}
