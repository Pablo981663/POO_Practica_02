#include <iostream>
#include "cat.h"

using namespace std;

int main(){
Gato Michi(4,6);
Michi.Maullar();
cout<<"Michi es un gato que tiene: ";
 cout<<Michi.ObtenerEdad()<<" anios de edad"<<endl;
 cout<<"y un peso de: "; cout<<Michi.ObtenerPeso()<<"kg"<<endl;

 return 0;
}
